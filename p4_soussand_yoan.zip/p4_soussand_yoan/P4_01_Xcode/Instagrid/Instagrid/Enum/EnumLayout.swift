//
//  EnumLayout.swift
//  Instagrid
//
//  Created by Yoan on 03/09/2021.
//

import Foundation

/// enum different case of photoContainer
enum Layout {
    case layout1, layout2, layout3
}
